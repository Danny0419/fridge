package com.example.fragment_test.pojo;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Food implements Parcelable {
    private Integer id;
    private String name;
    private String sort;
    private String quantity;
    private Integer state;

    public Food() {
    }
    public Food(Parcel source){
        this.id=source.readInt();
        this.name=source.readString();
        this.sort=source.readString();
        this.quantity=source.readString();
        this.state=source.readInt();
    }

    public Food(Integer id, String name, String sort, String quantity, Integer state) {
        this.id = id;
        this.name = name;
        this.sort = sort;
        this.quantity = quantity;
        this.state = state;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(sort);
        dest.writeString(quantity);
        dest.writeInt(state);
    }
    public static final Parcelable.Creator CREATOR = new Parcelable.Creator<Food>(){

        @Override
        public Food createFromParcel(Parcel source) {
            return new Food(source);
        }

        @Override
        public Food[] newArray(int size) {
            return new Food[size];
        }
    };
}
