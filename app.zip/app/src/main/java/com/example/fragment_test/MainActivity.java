package com.example.fragment_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.fragment_test.fragments.RecipeFragment;
import com.example.fragment_test.fragments.TestFragment;
import com.example.fragment_test.pojo.Food;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private SQLiteDatabase database;
    private ArrayList<Food> food;
    private Fragment testFragment,recipeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = openOrCreateDatabase("fridge_sys", Context.MODE_PRIVATE, null);

        ImageButton foodManagementButton = findViewById(R.id.foodManagementButton);
        ImageButton recipeButton = findViewById(R.id.recipeButton);


//        String sql = "create table  if not exists food(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,name text,sort text,quantity text,state INTEGER default 0)";
//        database.execSQL(sql);
//        sql = "insert into food values(null,'吳郭魚','魚肉類','3尾',0),(null,'吳郭魚','魚肉類','3尾',0),(null,'沙魚','魚肉類','4尾',0),(null,'吳郭魚','魚肉類','3尾',1),(null,'吳郭魚','魚肉類','3尾',1),(null,'吳郭魚','魚肉類','3尾',0),(null,'吳郭魚','魚肉類','3尾',0),(null,'吳郭魚','魚肉類','3尾',0),(null,'吳郭魚','魚肉類','3尾',0),(null,'吳郭魚','魚肉類','3尾',0)";
//        database.execSQL(sql);


        loadFoodManagementUI();
        foodManagementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFoodManagementUI();
            }
        });

        recipeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadRecipeUI();
            }
        });
    }

    public void loadFoodManagementUI(){
        food = getMyFood();

        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("food",food);

        TestFragment testFragment = new TestFragment();
        testFragment.setArguments(bundle);

        FragmentManager supportFragmentManager = this.getSupportFragmentManager();
        supportFragmentManager.beginTransaction()
                .replace(R.id.mainContent,testFragment)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public ArrayList<Food> getMyFood() {
        Cursor cursor = database.rawQuery("select * from food", null);
        ArrayList<Food> food = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String sort = cursor.getString(2);
            String quantity = cursor.getString(3);
            int state = cursor.getInt(4);
            food.add(new Food(id, name, sort, quantity, state));
        }
        return food;
    }

    public void loadRecipeUI(){
        recipeFragment = new RecipeFragment();

        FragmentManager supportFragmentManager = this.getSupportFragmentManager();
        supportFragmentManager.beginTransaction()
                .replace(R.id.mainContent,recipeFragment)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();

    }

}