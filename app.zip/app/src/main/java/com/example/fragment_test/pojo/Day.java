package com.example.fragment_test.pojo;

import java.util.ArrayList;

public enum Day {
    MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),
    FRIDAY("Friday"),SATURDAY("Saturday"),SUNDAY("Sunday");
    private String day;
    private ArrayList<Food> food;

    Day(String day) {
        this.day = day;
    }

    Day(String day, ArrayList<Food> food) {
        this.day = day;
        this.food = food;
    }

    public String getDay() {
        return day;
    }

    public ArrayList<Food> getFood() {
        return food;
    }

    public void setFood(ArrayList<Food> food) {
        this.food = food;
    }
}
